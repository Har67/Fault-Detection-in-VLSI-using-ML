"""
Gradio UI — ML-Based VLSI Fault Detection
4-bit ALU: ADD | SUB | AND | OR
Run: python3 app.py

Make sure to run ml_fault_detection.py first so the models are trained.
This app trains the models on startup (takes ~3 seconds).
"""

import gradio as gr
import pandas as pd
import numpy as np
import random
import warnings
warnings.filterwarnings('ignore')

from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

random.seed(42)
np.random.seed(42)


# ─────────────────────────────────────────────
# ALU Logic
# ─────────────────────────────────────────────

def alu(a, b, op):
    a, b = int(a), int(b)
    if op == 'ADD': return (a + b) & 0xF
    if op == 'SUB': return (a - b) & 0xF
    if op == 'AND': return a & b
    if op == 'OR':  return a | b


FAULTS = ['NoFault', 'SA0', 'SA1', 'RandomFault']
OPS    = ['ADD', 'SUB', 'AND', 'OR']


# ─────────────────────────────────────────────
# Train models on startup
# ─────────────────────────────────────────────

def inject_fault(a, b, op, fault):
    exp = alu(a, b, op)
    if fault == 'NoFault':     return exp
    if fault == 'SA0':         return 0
    if fault == 'SA1':         return 15
    if fault == 'RandomFault':
        choices = [x for x in range(16) if x != exp and x != 0 and x != 15]
        return random.choice(choices) if choices else (exp ^ 0b0101)


def generate_dataset(op, n_per_fault=400):
    rows = []
    for fault in FAULTS:
        for _ in range(n_per_fault):
            a   = random.randint(0, 15)
            b   = random.randint(0, 15)
            out = inject_fault(a, b, op, fault)
            exp = alu(a, b, op)
            rows.append({
                'A': a, 'B': b, 'Output': out, 'Expected': exp,
                'Diff': abs(exp - out), 'IsZero': int(out == 0),
                'IsOnes': int(out == 15), 'Match': int(out == exp),
                'Fault': fault
            })
    return pd.DataFrame(rows)


FEAT_COLS = ['A', 'B', 'Output', 'Expected', 'Diff', 'IsZero', 'IsOnes', 'Match']

print("Training models for all operations...")
trained_models = {}
model_accuracy = {}
model_coverage = {}

for op in OPS:
    df = generate_dataset(op, n_per_fault=400)
    X  = df[FEAT_COLS]; y = df['Fault']
    X_tr, X_te, y_tr, y_te = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y)
    clf = DecisionTreeClassifier(max_depth=12, random_state=42)
    clf.fit(X_tr, y_tr)
    preds = clf.predict(X_te)
    acc   = accuracy_score(y_te, preds)
    mask  = y_te != 'NoFault'
    cov   = accuracy_score(y_te[mask], preds[mask]) * 100 if mask.sum() else 0
    trained_models[op] = clf
    model_accuracy[op] = round(acc * 100, 2)
    model_coverage[op] = round(cov, 2)
    print(f"  {op}: accuracy={acc*100:.2f}%  coverage={cov:.2f}%")

print("Models ready.\n")


# ─────────────────────────────────────────────
# Prediction function
# ─────────────────────────────────────────────

def predict_fault(operation, a, b, output):

    try:
        a      = int(a)
        b      = int(b)
        output = int(output)
    except (ValueError, TypeError):
        return "Invalid input", "—", "—", "Please enter integers between 0 and 15"

    if not (0 <= a <= 15 and 0 <= b <= 15 and 0 <= output <= 15):
        return "Out of range", "—", "—", "All values must be between 0 and 15"

    op  = operation
    exp = alu(a, b, op)

    feat = pd.DataFrame([{
        'A':        a,
        'B':        b,
        'Output':   output,
        'Expected': exp,
        'Diff':     abs(exp - output),
        'IsZero':   int(output == 0),
        'IsOnes':   int(output == 15),
        'Match':    int(output == exp),
    }])

    clf        = trained_models[op]
    prediction = clf.predict(feat[FEAT_COLS])[0]
    acc        = model_accuracy[op]
    cov        = model_coverage[op]

    # Build a readable explanation
    if prediction == 'NoFault':
        detail = f"Output {output} matches expected {exp}. Circuit is healthy."
    elif prediction == 'SA0':
        detail = f"Output is 0 (stuck LOW). Expected was {exp}. Wire stuck at 0."
    elif prediction == 'SA1':
        detail = f"Output is 15 (stuck HIGH). Expected was {exp}. Wire stuck at 1."
    else:
        detail = f"Output {output} is incorrect (expected {exp}). Likely transient or random fault."

    return (
        prediction,
        f"{acc}%",
        f"{cov}%",
        detail
    )


# ─────────────────────────────────────────────
# Gradio UI
# ─────────────────────────────────────────────

with gr.Blocks(title="VLSI Fault Detection") as interface:

    gr.Markdown("""
    # ML-Based VLSI Fault Detection
    ### 4-bit ALU — ADD | SUB | AND | OR
    Select the operation, enter inputs A and B, enter the observed ALU output, and click **Predict Fault**.
    """)

    with gr.Row():
        with gr.Column():
            operation = gr.Dropdown(
                choices=OPS,
                value='ADD',
                label="ALU Operation"
            )
            input_a = gr.Number(label="Input A (0–15)", value=4, precision=0)
            input_b = gr.Number(label="Input B (0–15)", value=3, precision=0)
            output  = gr.Number(label="Observed ALU Output (0–15)", value=0, precision=0)
            btn     = gr.Button("Predict Fault", variant="primary")

        with gr.Column():
            fault_out    = gr.Textbox(label="Predicted Fault Type")
            accuracy_out = gr.Textbox(label="Model Accuracy")
            coverage_out = gr.Textbox(label="Fault Coverage")
            detail_out   = gr.Textbox(label="Explanation", lines=3)

    btn.click(
        fn=predict_fault,
        inputs=[operation, input_a, input_b, output],
        outputs=[fault_out, accuracy_out, coverage_out, detail_out]
    )

    gr.Markdown("""
    ---
    **Fault Types:**
    - **NoFault** — Output matches expected value; circuit is healthy
    - **SA0** — Stuck-At-0: output wire permanently LOW (output = 0)
    - **SA1** — Stuck-At-1: output wire permanently HIGH (output = 15)
    - **RandomFault** — Incorrect output due to transient or random fault

    **Model:** Decision Tree (max_depth=12) · Trained on 1600 samples per operation
    """)

    gr.Markdown("""
    ### Quick Test Examples
    | Operation | A | B | Injected Fault | Expected Output | Enter as Output |
    |-----------|---|---|----------------|-----------------|-----------------|
    | ADD | 4 | 3 | NoFault | 7 | 7 |
    | ADD | 4 | 3 | SA0 | 7 | 0 |
    | ADD | 4 | 3 | SA1 | 7 | 15 |
    | SUB | 9 | 4 | NoFault | 5 | 5 |
    | AND | 6 | 3 | SA0 | 2 | 0 |
    | OR  | 6 | 3 | SA1 | 7 | 15 |
    """)


# ─────────────────────────────────────────────
# Launch
# ─────────────────────────────────────────────

if __name__ == "__main__":
    interface.launch()
