import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import random
import warnings
warnings.filterwarnings('ignore')

from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, confusion_matrix, ConfusionMatrixDisplay, classification_report

random.seed(42)
np.random.seed(42)

def alu(a, b, op):
    if op == 'ADD': return (a + b) & 0xF
    if op == 'SUB': return (a - b) & 0xF
    if op == 'AND': return a & b
    if op == 'OR':  return a | b

FAULTS = ['NoFault', 'SA0', 'SA1', 'RandomFault']
OPS    = ['ADD', 'SUB', 'AND', 'OR']

def inject_fault(a, b, op, fault):
    exp = alu(a, b, op)
    if fault == 'NoFault': return exp
    if fault == 'SA0': return 0
    if fault == 'SA1': return 15
    if fault == 'RandomFault':
        choices = [x for x in range(16) if x != exp and x != 0 and x != 15]
        return random.choice(choices) if choices else (exp ^ 0b0101)

def generate_dataset(op, n_per_fault=400):
    rows = []
    for fault in FAULTS:
        for _ in range(n_per_fault):
            a   = random.randint(0, 15)
            b   = random.randint(0, 15)
            out = inject_fault(a, b, op, fault)
            exp = alu(a, b, op)
            rows.append({
                'A': a, 'B': b, 'Output': out, 'Expected': exp,
                'Diff': abs(exp - out), 'IsZero': int(out == 0),
                'IsOnes': int(out == 15), 'Match': int(out == exp),
                'Fault': fault
            })
    return pd.DataFrame(rows)

FEAT_COLS = ['A', 'B', 'Output', 'Expected', 'Diff', 'IsZero', 'IsOnes', 'Match']

trained_models = {}
all_datasets   = {}
results        = {}

print("=" * 58)
print("  VLSI Fault Detection - Extended ML Pipeline")
print("  Operations: ADD | SUB | AND | OR")
print("=" * 58)

for op in OPS:
    df = generate_dataset(op, n_per_fault=400)
    all_datasets[op] = df

    prefix = op.lower()
    df[df['Fault'] == 'NoFault'][['A','B','Output']].to_csv(f'{prefix}_nofault.txt', index=False, header=False)
    df[df['Fault'] == 'SA0'][['A','B','Output','Fault']].to_csv(f'{prefix}_sa0.txt', index=False, header=False)
    df[df['Fault'] == 'SA1'][['A','B','Output','Fault']].to_csv(f'{prefix}_sa1.txt', index=False, header=False)
    df[df['Fault'] == 'RandomFault'][['A','B','Output','Fault']].to_csv(f'{prefix}_random.txt', index=False, header=False)

    X = df[FEAT_COLS]; y = df['Fault']
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
    clf = DecisionTreeClassifier(max_depth=12, random_state=42)
    clf.fit(X_tr, y_tr)
    preds = clf.predict(X_te)
    acc   = accuracy_score(y_te, preds)
    mask  = y_te != 'NoFault'
    coverage = accuracy_score(y_te[mask], preds[mask]) * 100 if mask.sum() else 0

    trained_models[op] = clf
    results[op] = {'acc': round(acc*100,2), 'coverage': round(coverage,2)}

    print(f"\n  > {op}")
    print(f"    Model Accuracy : {acc*100:.2f}%")
    print(f"    Fault Coverage : {coverage:.2f}%")
    print(classification_report(y_te, preds, target_names=FAULTS, zero_division=0))
    print("-" * 58)

fig, axes = plt.subplots(2, 2, figsize=(14, 10))
fig.suptitle('Confusion Matrices - All ALU Operations', fontsize=14, fontweight='bold')
axes = axes.flatten()
for idx, op in enumerate(OPS):
    df  = all_datasets[op]; clf = trained_models[op]
    X   = df[FEAT_COLS]; y = df['Fault']
    _, X_te, _, y_te = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
    preds = clf.predict(X_te)
    cm    = confusion_matrix(y_te, preds, labels=FAULTS)
    disp  = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=FAULTS)
    disp.plot(ax=axes[idx], colorbar=False, cmap='Blues')
    axes[idx].set_title(f'{op} - Acc: {results[op]["acc"]}%')
    axes[idx].tick_params(axis='x', rotation=30)
plt.tight_layout()
plt.savefig('confusion_matrix_all.png', dpi=150, bbox_inches='tight')
plt.close()
print("Saved: confusion_matrix_all.png")

fig, axes = plt.subplots(1, 2, figsize=(12, 5))
fig.suptitle('ML Model Performance - All ALU Operations', fontsize=13, fontweight='bold')
colors = ['#4C72B0', '#DD8452', '#55A868', '#C44E52']
accs = [results[op]['acc'] for op in OPS]
covs = [results[op]['coverage'] for op in OPS]
axes[0].bar(OPS, accs, color=colors)
axes[0].set_title('Model Accuracy per Operation')
axes[0].set_ylabel('Accuracy (%)')
axes[0].set_ylim(0, 105)
for i, v in enumerate(accs):
    axes[0].text(i, v+0.5, f'{v:.1f}%', ha='center', fontweight='bold')
axes[1].bar(OPS, covs, color=colors)
axes[1].set_title('Fault Coverage per Operation')
axes[1].set_ylabel('Coverage (%)')
axes[1].set_ylim(0, 105)
for i, v in enumerate(covs):
    axes[1].text(i, v+0.5, f'{v:.1f}%', ha='center', fontweight='bold')
plt.tight_layout()
plt.savefig('accuracy_all_ops.png', dpi=150, bbox_inches='tight')
plt.close()
print("Saved: accuracy_all_ops.png")

print("\n" + "=" * 58)
print("  Final Summary")
print("=" * 58)
for op in OPS:
    print(f"  {op:<6} accuracy={results[op]['acc']:.2f}%   coverage={results[op]['coverage']:.2f}%")
print("=" * 58)
